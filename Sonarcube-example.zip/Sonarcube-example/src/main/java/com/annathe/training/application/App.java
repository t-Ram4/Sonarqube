package com.annathe.training.application;

public class App {
	
	
	public void show(int number) {
		
		System.out.println("inside show");
		
		Object obj = getObject();
		
		System.out.println(obj.toString());
		
	}
	
	private Object getObject() {
		
		return null;
	}

	public static void main(String arg[]) {
		
		App app = new App();
		
		app.show(0);
	}
}
